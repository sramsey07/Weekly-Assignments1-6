lightSpeed = 3*10**8
totalSeconds = 365*24*3600
lightYear = lightSpeed * totalSeconds

print("Light travels" , lightYear, "meters in a year")
